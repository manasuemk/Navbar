#This is created by manas

from django.http import HttpResponse
from django.shortcuts import render

def index(request):
    return render(request,"index.html")

def result(request):
    mytext=request.POST.get('text','default')
    pun=request.POST.get('pun','off')
    cap=request.POST.get('cap','off')
    rnl=request.POST.get('rnl','off')
    rs = request.POST.get('rs', 'off')
    analyzed = ""
    param={
        'state':'analyzed text',
        'output':analyzed
    }
    if pun=="on":
        punc= '''!()-[]{};:'"\,<>./?@#$%^&*_~'''
        for i in mytext:
            if i not in punc:
                analyzed=analyzed+i
        param['output']=analyzed
        mytext=analyzed

    if cap=="on":
        analyzed = ""
        for i in mytext:
            analyzed=analyzed+i.upper()
        param['output'] = analyzed
        mytext = analyzed

    if rnl == "on":
        analyzed = ""
        for i in mytext:
            if i != '\n' and i!='\r':
                analyzed=analyzed+i
        param['output'] = analyzed
        mytext = analyzed

    if rs=="on":
        analyzed=""
        for i in mytext:
            if i !=' ':
                analyzed=analyzed+i
        param['output']=analyzed
        mytext=analyzed

    return render(request,'analyzed.html',param)

